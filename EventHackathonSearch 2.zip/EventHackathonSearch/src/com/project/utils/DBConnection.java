package com.project.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/EventHackathonSearch";
    private static final String USER = "root"; // Replace with your MySQL username if different
    private static final String PASSWORD = ""; // Set this to your password, or leave it blank if none is set

    static {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Error loading JDBC Driver: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        // Establish and return the connection to the database
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void closeConnection(Connection conn) {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close(); // Close the connection if it's open
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
