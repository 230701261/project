package com.project.models;

public class User {
    private int id;
    private String username;
    private String password;
    private String role;
    private String college;
    private String email;
    private String approvalStatus;

    // Constructor
    public User(int id, String username, String password, String role, String college, String email, String approvalStatus) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
        this.college = college;
        this.email = email;
        this.approvalStatus = approvalStatus;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getCollege() {
        return college;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }
}
