package com.project.auth;

import com.project.dashboard.AdminDashboard;
import com.project.dashboard.StudentDashboard;
import com.project.dashboard.OrganizerDashboard;
import com.project.utils.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginPage extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleCombo;

    public LoginPage() {
        setTitle("EventConnect - Login");
        setSize(500, 400); // Initial size
        setMinimumSize(new Dimension(400, 300)); // Set minimum size for responsiveness
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel with BorderLayout to manage layout responsiveness
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(34, 49, 63));

        // Header panel with title
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(34, 49, 63));
        JLabel headerLabel = new JLabel("EventConnect Login", SwingConstants.CENTER);
        headerLabel.setFont(new Font("SansSerif", Font.BOLD, 26));
        headerLabel.setForeground(new Color(255, 215, 0)); // Gold color
        headerPanel.add(headerLabel);

        // Center panel with form
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(44, 62, 80));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Username
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(usernameLabel, gbc);

        usernameField = new JTextField(20);
        gbc.gridx = 1;
        formPanel.add(usernameField, gbc);

        // Password
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(passwordLabel, gbc);

        passwordField = new JPasswordField(20);
        gbc.gridx = 1;
        formPanel.add(passwordField, gbc);

        // Role dropdown
        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(roleLabel, gbc);

        String[] roles = {"student", "admin", "organizer"};
        roleCombo = new JComboBox<>(roles);
        gbc.gridx = 1;
        formPanel.add(roleCombo, gbc);

        // Buttons panel with FlowLayout for flexible alignment
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonsPanel.setBackground(new Color(34, 49, 63));

        // Login button
        JButton loginButton = new JButton("Login");
        styleButton(loginButton, new Color(72, 201, 176), Color.BLACK); // Seafoam green
        loginButton.addActionListener(new LoginAction());
        buttonsPanel.add(loginButton);

        // Register button
        JButton registerButton = new JButton("Register");
        styleButton(registerButton, new Color(93, 173, 226), Color.BLACK); // Light blue
        registerButton.addActionListener(e -> new RegisterPage().setVisible(true));
        buttonsPanel.add(registerButton);

        // Add panels to mainPanel with BorderLayout
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonsPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void styleButton(JButton button, Color bgColor, Color fgColor) {
        button.setBackground(bgColor);
        button.setForeground(fgColor);
        button.setFocusPainted(false);
        button.setFont(new Font("SansSerif", Font.BOLD, 16));
        button.setPreferredSize(new Dimension(120, 40));
    }

    private class LoginAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();
            String role = (String) roleCombo.getSelectedItem();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                return;
            }

            if (authenticateUser(username, password, role)) {
                JOptionPane.showMessageDialog(null, "Login successful as " + role);

                switch (role) {
                    case "student" -> new StudentDashboard().setVisible(true);
                    case "admin" -> new AdminDashboard().setVisible(true);
                    case "organizer" -> new OrganizerDashboard().setVisible(true);
                }
                dispose(); // Close the LoginPage after successful login
            } else {
                JOptionPane.showMessageDialog(null, "Invalid credentials. Please try again.");
            }
        }

        private boolean authenticateUser(String username, String password, String role) {
            String query = "SELECT * FROM users WHERE username = ? AND password = ? AND role = ?";
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, username);
                stmt.setString(2, password);
                stmt.setString(3, role);

                ResultSet rs = stmt.executeQuery();
                return rs.next(); // True if user exists, false otherwise
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
                ex.printStackTrace();
                return false;
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginPage().setVisible(true));
    }
}
