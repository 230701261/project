package com.project.dashboard;

import com.project.models.Event;
import com.project.services.EventService;
import com.project.services.RegistrationService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class StudentDashboard extends JFrame {
    private EventService eventService = new EventService();
    private RegistrationService registrationService = new RegistrationService();
    private JTable inCampusEventTable;
    private JTable otherCollegeEventTable;
    private DefaultTableModel inCampusTableModel;
    private DefaultTableModel otherCollegeTableModel;
    private int studentId;
    private String studentCollege;

    public StudentDashboard(int studentId, String college) {
        this.studentId = studentId;
        this.studentCollege = college;

        setTitle("Student Dashboard");
        setSize(900, 600);
        setMinimumSize(new Dimension(800, 600));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(34, 49, 63));
        JLabel headerLabel = new JLabel("Student Dashboard - Event Registration", SwingConstants.CENTER);
        headerLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        headerLabel.setForeground(new Color(255, 215, 0)); // Gold color
        headerPanel.add(headerLabel);

        // Main content panel with a GridLayout to remove spacing between panels
        JPanel contentPanel = new JPanel(new GridLayout(1, 2, 0, 0));

        // In-campus events panel
        JPanel inCampusPanel = new JPanel(new BorderLayout());
        inCampusPanel.setBorder(BorderFactory.createTitledBorder("In-Campus Events"));
        inCampusPanel.setBackground(new Color(44, 62, 80));

        inCampusTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Date", "Location"}, 0);
        inCampusEventTable = new JTable(inCampusTableModel);
        JScrollPane inCampusScrollPane = new JScrollPane(inCampusEventTable);
        inCampusPanel.add(inCampusScrollPane, BorderLayout.CENTER);

        JPanel inCampusButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        inCampusButtonPanel.setBackground(new Color(44, 62, 80));

        JButton registerInCampusButton = new JButton("Register");
        JButton unregisterInCampusButton = new JButton("Unregister");

        styleButton(registerInCampusButton, new Color(46, 204, 113), Color.BLACK);
        styleButton(unregisterInCampusButton, new Color(231, 76, 60), Color.BLACK);

        registerInCampusButton.addActionListener(new RegisterListener(inCampusEventTable));
        unregisterInCampusButton.addActionListener(new UnregisterListener(inCampusEventTable));

        inCampusButtonPanel.add(registerInCampusButton);
        inCampusButtonPanel.add(unregisterInCampusButton);
        inCampusPanel.add(inCampusButtonPanel, BorderLayout.SOUTH);

        // Other college events panel
        JPanel otherCollegePanel = new JPanel(new BorderLayout());
        otherCollegePanel.setBorder(BorderFactory.createTitledBorder("Other College Events"));
        otherCollegePanel.setBackground(new Color(44, 62, 80));

        otherCollegeTableModel = new DefaultTableModel(new String[]{"ID", "Name", "Date", "Location"}, 0);
        otherCollegeEventTable = new JTable(otherCollegeTableModel);
        JScrollPane otherCollegeScrollPane = new JScrollPane(otherCollegeEventTable);
        otherCollegePanel.add(otherCollegeScrollPane, BorderLayout.CENTER);

        JPanel otherCollegeButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        otherCollegeButtonPanel.setBackground(new Color(44, 62, 80));

        JButton registerOtherCollegeButton = new JButton("Register");
        styleButton(registerOtherCollegeButton, new Color(46, 204, 113), Color.BLACK);
        registerOtherCollegeButton.addActionListener(new RegisterListener(otherCollegeEventTable));

        otherCollegeButtonPanel.add(registerOtherCollegeButton);
        otherCollegePanel.add(otherCollegeButtonPanel, BorderLayout.SOUTH);

        // Add the panels to the content panel
        contentPanel.add(inCampusPanel);
        contentPanel.add(otherCollegePanel);

        // Add header and content panels to the main layout
        add(headerPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);

        loadInCampusEvents();
        loadOtherCollegeEvents();
    }

    private void styleButton(JButton button, Color bgColor, Color fgColor) {
        button.setBackground(bgColor);
        button.setForeground(fgColor);
        button.setFocusPainted(false);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setPreferredSize(new Dimension(120, 40));
    }

    // Load in-campus events specific to the student's college
    private void loadInCampusEvents() {
        inCampusTableModel.setRowCount(0); // Clear existing rows
        List<Event> events = eventService.getEventsByCollege(studentCollege);
        for (Event event : events) {
            inCampusTableModel.addRow(new Object[]{event.getId(), event.getName(), event.getDate(), event.getLocation()});
        }
    }

    // Load events from other colleges
    private void loadOtherCollegeEvents() {
        otherCollegeTableModel.setRowCount(0); // Clear existing rows
        List<Event> events = eventService.getAllEvents();
        for (Event event : events) {
            if (!event.getCollege().equals(studentCollege)) {
                otherCollegeTableModel.addRow(new Object[]{event.getId(), event.getName(), event.getDate(), event.getLocation()});
            }
        }
    }

    // Event listener for registering to an event
    private class RegisterListener implements ActionListener {
        private JTable targetTable;

        public RegisterListener(JTable targetTable) {
            this.targetTable = targetTable;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = targetTable.getSelectedRow();
            if (selectedRow != -1) {
                int eventId = (int) targetTable.getValueAt(selectedRow, 0);
                if (registrationService.registerForEvent(studentId, eventId)) {
                    JOptionPane.showMessageDialog(StudentDashboard.this, "Registration request sent. Awaiting approval.");
                } else {
                    JOptionPane.showMessageDialog(StudentDashboard.this, "Registration failed.");
                }
            } else {
                JOptionPane.showMessageDialog(StudentDashboard.this, "Please select an event to register.");
            }
        }
    }

    // Event listener for unregistering from an event
    private class UnregisterListener implements ActionListener {
        private JTable targetTable;

        public UnregisterListener(JTable targetTable) {
            this.targetTable = targetTable;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = targetTable.getSelectedRow();
            if (selectedRow != -1) {
                int eventId = (int) targetTable.getValueAt(selectedRow, 0);
                if (registrationService.unregisterFromEvent(studentId, eventId)) {
                    JOptionPane.showMessageDialog(StudentDashboard.this, "Successfully unregistered from the event.");
                } else {
                    JOptionPane.showMessageDialog(StudentDashboard.this, "Unregistration failed.");
                }
            } else {
                JOptionPane.showMessageDialog(StudentDashboard.this, "Please select an event to unregister.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StudentDashboard(2, "Rajalakshmi Engineering College").setVisible(true)); // Example student ID and college
    }
}
