package com.project.services;

import com.project.models.Registration;
import com.project.utils.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RegistrationService {

    // Register a student for an event (sets default approval status to 'pending')
    public boolean registerForEvent(int userId, int eventId) {
        String query = "INSERT INTO registrations (user_id, event_id, approval_status) VALUES (?, ?, 'pending')";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, userId);
            stmt.setInt(2, eventId);
            int rowsAffected = stmt.executeUpdate();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Update the approval status of a registration
    public boolean updateRegistrationStatus(int registrationId, String status) {
        String query = "UPDATE registrations SET approval_status = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, status);
            stmt.setInt(2, registrationId);
            int rowsAffected = stmt.executeUpdate();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Retrieve all pending registrations for a specific college
    public List<Registration> getPendingRegistrationsByCollege(String college) {
        List<Registration> registrations = new ArrayList<>();
        String query = "SELECT r.id, r.user_id, r.event_id, r.registration_date, r.approval_status " +
                       "FROM registrations r " +
                       "JOIN events e ON r.event_id = e.id " +
                       "WHERE e.college = ? AND r.approval_status = 'pending'";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, college);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Registration registration = new Registration(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getInt("event_id"),
                        rs.getTimestamp("registration_date"),
                        rs.getString("approval_status")
                );
                registrations.add(registration);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return registrations;
    }

    // Retrieve all registrations for a specific user
    public List<Registration> getRegistrationsByUser(int userId) {
        List<Registration> registrations = new ArrayList<>();
        String query = "SELECT * FROM registrations WHERE user_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Registration registration = new Registration(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getInt("event_id"),
                        rs.getTimestamp("registration_date"),
                        rs.getString("approval_status")
                );
                registrations.add(registration);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return registrations;
    }
}
