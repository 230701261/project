package com.project.services;

import com.project.models.User;
import com.project.utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserService {

    // Authenticate a user based on username, password, and role
    public User authenticateUser(String username, String password, String role) {
        String query = "SELECT * FROM users WHERE username = ? AND password = ? AND role = ? AND approval_status = 'approved'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, role);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("college"),
                        rs.getString("email"),
                        rs.getString("approval_status")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Return null if authentication fails
    }

    // Retrieve all organizers with pending approval status
    public List<User> getPendingOrganizers() {
        List<User> organizers = new ArrayList<>();
        String query = "SELECT * FROM users WHERE role = 'organizer' AND approval_status = 'pending'";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                User user = new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role"),
                        rs.getString("college"),
                        rs.getString("email"),
                        rs.getString("approval_status")
                );
                organizers.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return organizers;
    }

    // Approve or reject a pending organizer registration
    public boolean updateOrganizerApprovalStatus(int organizerId, String status) {
        String query = "UPDATE users SET approval_status = ? WHERE id = ? AND role = 'organizer'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, status);
            stmt.setInt(2, organizerId);
            int rowsAffected = stmt.executeUpdate();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
