package com.project.services;

import com.project.models.Event;
import com.project.utils.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EventService {

    // Fetch all events by college
    public List<Event> getEventsByCollege(String college) {
        List<Event> events = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM events WHERE college = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, college);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Event event = mapResultSetToEvent(rs);
                events.add(event);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return events;
    }

    // Fetch all events without any college filter
    public List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM events";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Event event = mapResultSetToEvent(rs);
                events.add(event);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return events;
    }

    // Add a new event
    public boolean addEvent(Event event) {
        String sql = "INSERT INTO events (event_name, event_description, event_date, location, college, created_by, event_poster) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, event.getName());
            stmt.setString(2, event.getDescription());
            stmt.setDate(3, new java.sql.Date(event.getDate().getTime()));
            stmt.setString(4, event.getLocation());
            stmt.setString(5, event.getCollege());
            stmt.setInt(6, event.getCreatedBy());
            stmt.setString(7, event.getPosterPath());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Update an existing event
    public boolean updateEvent(Event event) {
        String sql = "UPDATE events SET event_name = ?, event_description = ?, event_date = ?, location = ?, event_poster = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, event.getName());
            stmt.setString(2, event.getDescription());
            stmt.setDate(3, new java.sql.Date(event.getDate().getTime()));
            stmt.setString(4, event.getLocation());
            stmt.setString(5, event.getPosterPath());
            stmt.setInt(6, event.getId());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete an event by ID
    public boolean deleteEvent(int eventId) {
        String sql = "DELETE FROM events WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, eventId);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Helper method to map a ResultSet row to an Event object
    private Event mapResultSetToEvent(ResultSet rs) throws SQLException {
        return new Event(
                rs.getInt("id"),
                rs.getString("event_name"),
                rs.getString("event_description"),
                rs.getDate("event_date"),
                rs.getString("location"),
                rs.getString("college"),
                rs.getInt("created_by"),
                rs.getString("event_poster")
        );
    }
}
